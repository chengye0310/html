<?php
    if ($_POST["id"]=="tony" && $_POST["pwd"]=="1234")
        echo "login success";
    else
        echo "login fail";
?>